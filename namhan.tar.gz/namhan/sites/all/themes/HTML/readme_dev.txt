1) index3.html Header Slider.
- captions can be places in 6 places, just add one of class to slide div.
.caption_lt - left-top
.caption_lc - left-center
.caption_lb - left-bottom
.caption_rt - right-top
.caption_rc - right-center
.caption_rb - right-bottom
if BG image is very "light" you can add class ".caption_dark" to make caption dark colored.

2) buttons class now is ".btn" (was .button_link or .button) was conflict with revolution slider

3) index.html index2.html index3.html 
- <div class="body_wrap homepage"> need to have class homepage

4) MultiSelect Listbox (offers-search-multi.html)
- DIV with MultiSelect need to have classes <div class="row field_multiselect"> and html structure for Listbox is in offers-search-multi.html field "Car Makers"
- JS is in general.js
