<?php foreach ($rows as $id => $row): ?>
<div class="special_item">
    <?php print $row; ?>
</div>
<?php endforeach; ?>