<div class="special_image">
    <a href="offers-details.html"><?php print $fields['field_image']->content ?></a>
</div>
<div class="special_text">
    <h3><a href="offers-details.html"><?php print $fields['title']->raw ?></a></h3>
    <div><?php print $fields['body']->content ?></div>
</div>