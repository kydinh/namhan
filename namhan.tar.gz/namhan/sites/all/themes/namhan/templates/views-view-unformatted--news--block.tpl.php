<div class="special_item">
    <div class="special_image">
        <a href="offers-details.html"><img src="images/temp/special_offer_1.jpg" alt=""></a>
    </div>
    <div class="special_text">
        <h3><a href="offers-details.html">Range Rover Evoque</a></h3>
        <div class="info_row"><span>FIRST REG:</span> FEB 2013</div>
        <div class="info_row"><span>FUEL CONS:</span> 32,6 MPG</div>
        <div class="info_row"><span>MILEAGE</span> 170,443</div>
        <div class="special_price">$32.690</div>
    </div>
</div>

<div class="special_item">
    <div class="special_image">
        <a href="offers-details.html"><img src="images/temp/special_offer_2.jpg" alt=""></a>
    </div>
    <div class="special_text">
        <h3><a href="offers-details.html">Alfa Romeo Mito</a></h3>
        <div class="info_row"><span>FIRST REG:</span> AUG 2012</div>
        <div class="info_row"><span>FUEL CONS:</span> 56,6 MPG</div>
        <div class="info_row"><span>MILEAGE</span> 30,443</div>
        <div class="special_price">$15.690</div>
    </div>
</div>

<div class="special_item">
    <div class="special_image">
        <a href="offers-details.html"><img src="images/temp/special_offer_3.jpg" alt=""></a>
    </div>
    <div class="special_text">
        <h3><a href="offers-details.html">Mercedes CLA 220d</a></h3>
        <div class="info_row"><span>FIRST REG:</span> NOV 2012</div>
        <div class="info_row"><span>FUEL CONS:</span> 42,6 MPG</div>
        <div class="info_row"><span>MILEAGE</span> 12,443</div>
        <div class="special_price">$44.690</div>
    </div>
</div>