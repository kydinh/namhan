<!-- week offer -->

    <?php if ($title): ?><h2>
            <?php print $title; ?>
        </h2><?php endif; ?>
    <div class="offer_box">
        <?php print $rows; ?>
    </div>

<!../images/--/ week offer -->