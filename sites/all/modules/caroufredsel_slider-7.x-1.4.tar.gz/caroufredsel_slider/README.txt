
CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Installation
 * Dependencies
 * Templates


INTRODUCTION
------------

Field formatter providing the carouFredSel jQuery slideshow
(http://caroufredsel.dev7studios.com) as a display formatter for image fields.


INSTALLATION
------------

1. Download library from http://caroufredsel.dev7studios.com/download.php.

2. Extract all contents to sites/all/libraries/caroufredsel (e.g. 
   jquery.carouFredSel-6.2.0.js should be in this directory).


DEPENDENCIES
------------

* Libraries (http://drupal.org/project/libraries)


TEMPLATES
------------

You can copy the following templates to your theme and adjust the sliders
output:

* caroufredsel-slider.tpl.php (Wrapper for the slider element)
* caroufredsel-slider-item.tpl.php (Individual item in slider)
