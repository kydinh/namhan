<div id="<?php print $variables['vss_id']; ?>_<?php print $variables['count']; ?>" class="<?php print $classes; ?>">
  <?php print $rendered_items; ?>
</div>
