<div id="<?php print $variables['vss_id']; ?>" class="<?php print $classes; ?>">
  <?php print $rendered_rows; ?>
</div>
